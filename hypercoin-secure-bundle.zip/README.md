# HyperCoin Secure Core

This repository contains the secure ABI and interaction scripts for managing WrappedHyperCoin.

## Setup

1. Clone the repo
2. Create a `.env` file based on `.env.example`
3. Install dependencies and run scripts via Hardhat

## Security

- Never share the `.env` file or expose your private key.
- Source code is intentionally unpublished to protect minting logic.

