const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  const contractAddress = "0xYourContractAddress";

  const WrappedHyperCoin = await hre.ethers.getContractAt("WrappedHyperCoin", contractAddress);
  const tx = await WrappedHyperCoin.setEthereumLockContract("0xYourLockContract");
  await tx.wait();

  console.log("Ethereum Lock Contract set!");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
